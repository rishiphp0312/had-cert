package in.edureka.mapreduce;


import in.edureka.mapreduce.WordCountIdentityReducer.Map;

import java.io.IOException;
import java.net.*;
import java.nio.file.FileSystem;
import java.util.*;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.conf.Configuration;
//import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.mapred.Mapper;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.Reducer;
import org.apache.hadoop.mapred.Reporter;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.JobClient;
import org.apache.hadoop.mapred.TextInputFormat;
import org.apache.hadoop.mapred.TextOutputFormat;

//import org.apache.hadoop.mapred.lib.;
import org.apache.hadoop.mapred.FileInputFormat;
import org.apache.hadoop.mapred.FileOutputFormat;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Partitioner;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Reducer.Context;

public  class WordPartitionClass 
{
	//extends Partitioner<Text, IntWritable>
	
	
	public static class Map extends MapReduceBase implements  Mapper<LongWritable,Text,Text,IntWritable>{

		public void map(LongWritable key, Text value,OutputCollector<Text, IntWritable> output,
				Reporter reporter)
				throws IOException {
			
			String line = value.toString();
			/*StringTokenizer tokenizer = new StringTokenizer(line);
			//for()
			while (tokenizer.hasMoreTokens()) {
				value.set(tokenizer.nextToken());
				context.write(value, new IntWritable(1));
			}*/
			for(String x: line.split(" ")){
				output.collect(new Text(x) , new IntWritable(1));
			}
			
		}
		
	}
	
	public static class Reduce extends MapReduceBase implements  Reducer<Text,IntWritable,Text,IntWritable>{

		public void reduce(Text key, Iterable<IntWritable> values,
				,OutputCollector<Text, IntWritable> output,Reporter reporter)
				throws IOException {
			int sum=0;
			// TODO Auto-generated method stub
			for(IntWritable x: values)
			{
				sum+=x.get();
			}
			output.collect(key, new IntWritable(sum));			
		}
		
		
		public static class MyPartitionClass implements Partitioner<Text, IntWritable>{
			

			public int getPartition(Text key, IntWritable value, int numPartitions)

			{

				String emp_dept = key.toString().toLowerCase();

				if(numPartitions == 0)

						return 0;

				if(emp_dept.equals(“slave”))

				{

					return 0;

				}

				else if(emp_dept.equals(“and”))

				{

					return 1 ;

				}

				else

					return 2 ;

			}
			
			
			public void configure(JobConf arg0){
				
			}
			
		}
		
		

		public static void main(String[] args) throws Exception {
			// TODO Auto-generated method stub		
			//JobConf conf = new JobConf(WordCount.class);
			//Configuration conf= new Configuration();	
			//conf.setJobName("mywc");
			
			Job job = new JobConf(WordPartitionClass.class);
			job.setNumReduceTasks(3);

			job.setJobName("partitioner");
			//job.setCombinerClass(Reduce.class); ask this from edu
			job.setMapperClass(Map.class);
			job.setReducerClass(Reduce.class);
			job.setPartitionerClass(MyPartitionClass.class);
			
			//conf.setMapperClass(Map.class);
			//conf.setReducerClass(Reduce.class);

			job.setOutputKeyClass(Text.class);
			job.setOutputValueClass(IntWritable.class);
			
			job.setInputFormatClass(TextInputFormat.class);
			job.setOutputFormatClass(TextOutputFormat.class);
			
			

			Path outputPath = new Path(args[1]);
				
		        //Configuring the input/output path from the filesystem into the job
		        
		    FileInputFormat.setInputPath(job, new Path(args[0]));
		    FileOutputFormat.setOutputPath(job, new Path(args[1]));
		    //URI uri = new URI(args[1].toString());
		    //FileSystem fs =  FileSystem.get(uri,conf);
		    //boolean x = fs.delete(new Path(uri),true);
				
				//deleting the output path automatically from hdfs so that we don't have delete it explicitly
				
			//outputPath.getFileSystem(job).delete(outputPath);
				JobClient.runJob(job);
				//exiting the job only if the flag value becomes false
				
			//System.exit(job.waitForCompletion(true) ? 0 : 1);
		}



}
