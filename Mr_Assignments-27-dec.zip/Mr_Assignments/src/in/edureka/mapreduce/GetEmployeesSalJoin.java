package in.edureka.mapreduce;

import java.io.IOException;
import java.nio.file.FileSystem;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
//import org.apache.hadoop.mapreduce.lib.*;
//import org.apache.hadoop.mapreduce.lib.*;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.MultipleInputs;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

//import WordCount.WordCountDriver;
//import WordCount.WordCountDriver.Map;
//import WordCount.WordCountDriver.Reduce;

public class GetEmployeesSalJoin {

	public static class EmployeeName extends Mapper<LongWritable,Text,IntWritable,Text>{

		public void map(LongWritable key, Text value,
				Context context)
				throws IOException,InterruptedException {
			
			String line = value.toString().trim();
			//try{
				Integer id  = Integer.parseInt(line.split(" ")[0]);
					
			//}catch(){
				
			//}
			/*StringTokenizer tokenizer = new StringTokenizer(line);
			//for()
			while (tokenizer.hasMoreTokens()) {
				value.set(tokenizer.nextToken());
				context.write(value, new IntWritable(1));
			}*/
			//for(String x: line.split(" ")){
				context.write(new IntWritable(id) , new Text(
						"EName"+" "+line.split(" ")[0]+" "+line.split(" ")[1]));
			//}
			
		}
		
	}
	
	public static class EmployeeSalry extends Mapper<LongWritable,Text,IntWritable,Text>{

		public void map(LongWritable key, Text value,
				Context context)
				throws IOException,InterruptedException {
			
			String line = value.toString().trim();
			Integer id  = Integer.parseInt(line.split(" ")[0]);
			/*StringTokenizer tokenizer = new StringTokenizer(line);
			//for()
			while (tokenizer.hasMoreTokens()) {
				value.set(tokenizer.nextToken());
				context.write(value, new IntWritable(1));
			}*/
			//for(String x: line.split(" ")){
			context.write(new IntWritable(id) , new Text(
					"ESal"+" "+line.split(" ")[0]+" "+line.split(" ")[1]));
			//}
			
		}
		
	}
	
	
	public static class Reduce extends Reducer<IntWritable,Text,Text,IntWritable>{

		public void reduce(IntWritable key, Iterable<Text> values,
				Context context)
				throws IOException,InterruptedException {
			///222 {ESAl 2300, ESAl 3400 ,ENAME Raj}
			String  Ename = "" ;
			Integer totSal = 0;
			// TODO Auto-generated method stub
			//String[] splitLine = values.split('|').toString().toLowerCase();
			for(Text x: values){
				if (x.toString().trim().split(" ")[0].toLowerCase().equals("ename")) {
					 Ename = x.toString().trim().split(" ")[2];
				}
				if (x.toString().trim().split(" ")[0].toLowerCase().equals("esal")) {
					totSal +=  Integer.parseInt(x.toString().trim().split(" ")[2]);
				}
			}
			
			//String fin = Ename+"--"+sal;
			
			context.write(new Text(Ename), new IntWritable(totSal));
			
		}
		
	}
	
	
	@SuppressWarnings("deprecation")
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		
		//JobConf conf = new JobConf(WordCount.class);
		Configuration conf= new Configuration();
		
		
		//conf.setJobName("mywc");
		@SuppressWarnings("deprecation")
		Job job = new Job(conf,"mywc");
		
		job.setJarByClass(GetEmployeesSalJoin.class);
		job.setReducerClass(Reduce.class);
		//job.setMapperClass(EmployeeName.class);
	    //job.setMapperClass(EmployeeSalry.class);
		job.setOutputKeyClass(IntWritable.class);
		job.setOutputValueClass(Text.class);

				
		//job.setInputFormatClass(IntWritable.class);
		//job.setOutputFormatClass(TextOutputFormat.class);
		//job.setInputFormatClass(IntWritable.class);;
		//job.setInputFormatClass(cls);(Text.class);
		//job.setOutputKeyClass(Text.class);
		//job.setOutputValueClass(IntWritable.class);
		
		

		Path outputPath = new Path(args[2]);
			
	        //Configuring the input/output path from the filesystem into the job
		MultipleInputs.addInputPath(job, new Path(args[0]), TextInputFormat.class,EmployeeName.class);
	        
	    //MultipleInputs.addInputPath(job, new Path(args[0]),TextInputFormat.class,EmployeeName.class);//ename
	    MultipleInputs.addInputPath(job, new Path(args[1]),TextInputFormat.class,EmployeeSalry.class);//esal 
	    //FileOutputFormat.setOutputPath(job, new Path(args[2]));
		//job.setReducerClass(Reduce.class);

			//deleting the output path automatically from hdfs so that we don't have delete it explicitly
			//FileSystem fs = FileSystem.get(conf);
			//fs.delete(new Path(args[2]));
			//exiting the job only if the flag value becomes false
	    FileOutputFormat.setOutputPath(job, outputPath);
		outputPath.getFileSystem(conf).delete(outputPath);

		System.exit(job.waitForCompletion(true)?0:1);
	}
	
	
}
