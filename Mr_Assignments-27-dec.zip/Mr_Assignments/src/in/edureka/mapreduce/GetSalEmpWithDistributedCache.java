package in.edureka.mapreduce;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.net.URI;
import java.util.HashMap;
import java.util.Map;





import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.filecache.DistributedCache;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper.Context;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.Counter;
import org.apache.hadoop.mapreduce.Counters;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;

import java.util.logging.Logger;
import java.util.logging.Level;



public class GetSalEmpWithDistributedCache {

	private static Logger logger = Logger.getLogger(GetSalEmpWithDistributedCache.class.getName());
	
	public static class MyMapper extends Mapper<LongWritable,Text, Text, Text> {
		
		private Map<String, String> abMap = new HashMap<String, String>();
		private Text outputKey  = new Text();
		private Text outputValue  = new Text();
		
		
		
		protected void setup(Context context) throws java.io.IOException, InterruptedException{
			Path[] files = DistributedCache.getLocalCacheFiles(context.getConfiguration());
			
			
			for (Path p : files) {
				
				if (p.getName().equals("abc.dat")) {
				//if (p.getName().equals("EmpjoinCode/employeeName.txt")) {
					BufferedReader reader = new BufferedReader(new FileReader(p.toString()));
					String line = reader.readLine();
					while(line != null) {
						//logger.log(Level.INFO,"setup -line==="+line);

						String[] tokens = line.split("\t");
						String ab = tokens[0];
						//logger.log(Level.INFO,"setup -ab==="+ab);
						String state = tokens[1];
						//logger.log(Level.INFO,"setup -state==="+state);
						abMap.put(ab, state);
						line = reader.readLine();
						logger.log(Level.INFO,"setup -abMap==="+abMap);
					}
				}
			}
			if (abMap.isEmpty()) {
				throw new IOException("Unable to load Abbrevation data.");
			}
		}

		
        protected void map(LongWritable key, Text value, Context context)
            throws java.io.IOException, InterruptedException {
        	
        	
        	String row = value.toString();
        	String[] tokens = row.split(" ");
        	String EmpId = tokens[0];
        	String EmpName = abMap.get(EmpId);
        	logger.log(Level.INFO,"map -abMap==="+EmpName);
        	outputKey.set(EmpName);
        	outputValue.set(row);
      	  	context.write(outputKey,outputValue);
        }  
}
	
	
  public static void main(String[] args) 
                  throws IOException, ClassNotFoundException, InterruptedException {
    
    Job job = new Job();
    job.setJarByClass(GetSalEmpWithDistributedCache.class);
    job.setJobName("DCTest");
    job.setNumReduceTasks(0);
    
    try{
    DistributedCache.addCacheFile(new Path(args[2]).toUri(), job.getConfiguration());
    }catch(Exception e){
    	System.out.println(e);
    }
    
    job.setMapperClass(MyMapper.class);
    
    job.setMapOutputKeyClass(Text.class);
    job.setMapOutputValueClass(Text.class);
	//logger.log(Level.INFO,"main 1 arg==="+new Path(args[0]));
	//logger.log(Level.INFO,"main 2 arg==="+new Path(args[1]));

    FileInputFormat.addInputPath(job, new Path(args[0]));
    FileOutputFormat.setOutputPath(job, new Path(args[1]));
	//logger.log(Level.INFO,"main 1 arg==="+args[0]);

    
    System.exit(job.waitForCompletion(true)?0:1);
    
    
  }
}

/*
@SuppressWarnings("deprecation")
public class GetSalEmpWithDistributedCache {

	public static class EmployeeName extends Mapper<LongWritable,Text,Text,Text> {
		
		private Map<String, String> abMap = new HashMap<String, String>();
		private Text outputKey  = new Text();
		private Text outputValue  = new Text();
		
		protected void setup(Context con) throws java.io.IOException,InterruptedException{
		Path[] files =  DistributedCache.getLocalCacheFiles(con.getConfiguration());
		for(Path p : files) {
			if(p.getName().equals("EmpjoinCode/employeeName.txt")) {
				BufferedReader reader = new BufferedReader(new FileReader(p.toString()));
				String line = reader.readLine();
				while(line!=null) {
					
				String[] tokens = line.split(" ");
				String id  =tokens[0];
				String name  =tokens[1];
				abMap.put(id,name);
				line = reader.readLine();
			    }
		    }
		}
		}
		}
		
	protected void map(LongWritable key, Text value, Context context)
            throws java.io.IOException, InterruptedException {
        	
        	
        	String row = value.toString();
        	String[] tokens = row.split(" ");
        	String inab = tokens[0];
        	String state = abMap.get(inab);
        	//outputKey.set(state);
        	outputValue.set(row);
      	  	//context.write(outputKey,outputValue);
        }  
			

		
		
	}
	
	
	
	@SuppressWarnings("deprecation")
	public static void main(String[] args)
			throws IOException, ClassNotFoundException, InterruptedException {
		// TODO Auto-generated method stub		
		 	Job job = new Job();
		    job.setJarByClass(GetSalEmpWithDistributedCache.class);
		    job.setJobName("DCTest");
		    job.setNumReduceTasks(0);
		    
		    try{
		        DistributedCache.addCacheFile(new URI("EmpjoinCode/employeeName.txt"), job.getConfiguration());
		        }catch(Exception e){
		        	System.out.println(e);
		        }    
		    
			job.setMapperClass(EmployeeName.class);
			job.setMapOutputKeyClass(Text.class);
			job.setMapOutputValueClass(Text.class);
			FileInputFormat.addInputPath(job, new Path(args[0]));
		    FileOutputFormat.setOutputPath(job, new Path(args[1]));	
		   	System.exit(job.waitForCompletion(true)?0:1);
	}
	
	
}*/
