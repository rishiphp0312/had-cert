package airline;


import java.io.IOException;
import java.util.StringTokenizer;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

// Answer D


public class HighestAirports {
	
	public static class MyMap extends Mapper<LongWritable,Text,Text,IntWritable>{
		public void map(LongWritable key, Text value,
				Context context)
				throws IOException,InterruptedException {
			
			String line = value.toString();
			context.write(new Text(line.split(",")[3]) , new IntWritable(1));
						
		}
		
	}
	
	
	public static class MyReduce extends Reducer<Text,IntWritable,Text,IntWritable>{
		
		
		private  HashMap<String, Integer>countryNames = new HashMap<String, Integer>();
		private   Integer  maxVal=0 ;			

		public void reduce(Text key, Iterable<IntWritable> values,
				Context context)
				throws IOException,InterruptedException {
			  
			int sum=0;
			
			// TODO Auto-generated method stub
			for(IntWritable x: values)
			{
				sum+=x.get();
			}
			countryNames.put(key.toString(), sum);
			
			//result.set(sum);
	         if(sum >= maxVal){
	        	 maxVal=  sum;
	        	 
	         }		
	         
	         //context.write(new Text(key.toString())  ,new IntWritable(sum));
		}
	
		public void cleanup(Context context) throws IOException, InterruptedException{
			   
			  for( @SuppressWarnings("unused") Map.Entry<String,Integer> mapEntry :countryNames.entrySet()){
				  Integer valKey = mapEntry.getValue();
				  if(Objects.equals(maxVal,mapEntry.getValue())){
					 context.write(new Text(mapEntry.getKey().toString())  ,new IntWritable(maxVal));
				   }
			   }
			   
		   }
	} //Reducer ends here
	
	public static void main(String[] args) throws Exception 
	   {
	      Configuration conf = new Configuration();
	      Job job = Job.getInstance(conf, "word count");
			
	      job.setJarByClass(HighestAirports.class);
	      job.setMapperClass(MyMap.class);
	      job.setCombinerClass(MyReduce.class);
			
	      job.setOutputKeyClass(Text.class);
	      job.setOutputValueClass(IntWritable.class);
			
	      FileInputFormat.addInputPath(job, new Path(args[0]));
	      FileOutputFormat.setOutputPath(job, new Path(args[1]));
			Path outputPath = new Path(args[1]);

			outputPath.getFileSystem(conf).delete(outputPath);

			
	      System.exit(job.waitForCompletion(true) ? 0 : 1);
	   }
}

